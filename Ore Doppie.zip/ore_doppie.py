# Copyright (C) 2025 Francesco Piroddi
# Licenza: GNU General Public License v3.0
# Questo programma è distribuito con la speranza che sia utile,
# ma SENZA ALCUNA GARANZIA; senza neanche la garanzia implicita di
# COMMERCIABILITÀ o IDONEITÀ PER UN DATO SCOPO. Consulta la Licenza
# Pubblica Generale GNU per maggiori dettagli.
# Puoi ottenere una copia della licenza al seguente indirizzo:
# https://www.gnu.org/licenses/gpl-3.0.html

def significato_ore_doppie(ora):
    significati = {
        "00:00": "Nuovo inizio, concentrati sulla tua spiritualità e sui cambiamenti positivi.",
        "01:01": "Segui i tuoi sogni. C'è un'energia di manifestazione e realizzazione.",
        "02:02": "Equilibrio e armonia nelle relazioni. Mantieni la pace.",
        "03:03": "Focalizzati sulla tua crescita interiore e nuovi progetti.",
        "04:04": "Stabilità e costruzione di una base solida per il futuro.",
        "05:05": "Il cambiamento è in arrivo. Preparati a nuove opportunità.",
        "06:06": "Amore e affetto. Concentrati sulla felicità e la positività.",
        "07:07": "Benedizioni divine. Protezione e guida dagli angeli.",
        "08:08": "Abbondanza e prosperità. Credi in te stesso e nelle tue capacità.",
        "09:09": "Completamento di cicli. Lascia andare il passato per fare spazio al nuovo.",
        "10:10": "Prestare attenzione ai tuoi pensieri. Allineati con la tua verità interiore.",
        "11:11": "Risveglio spirituale. Mantieni alta la tua vibrazione.",
        "12:12": "Sei sulla giusta strada. Il tuo cammino è in armonia con il tuo scopo divino.",
        "22:22": "Equilibrio tra forze spirituali e materiali. Persevera, il successo è vicino."
    }
    return significati.get(ora, "Ora non valida.")

def main():
    ore_doppie = [
        "00:00", "01:01", "02:02", "03:03", "04:04", 
        "05:05", "06:06", "07:07", "08:08", "09:09", 
        "10:10", "11:11", "12:12", "22:22"
    ]

    print("Elenco delle ore doppie disponibili:")
    for i, ora in enumerate(ore_doppie, 1):
        print(f"{i}. {ora}")

    scelta = int(input("\nSeleziona il numero dell'ora doppia per ricevere il significato (1-14): "))
    
    if 1 <= scelta <= 14:
        ora_selezionata = ore_doppie[scelta - 1]
        print(f"\nIl significato dell'ora doppia {ora_selezionata} è: {significato_ore_doppie(ora_selezionata)}")
    else:
        print("\nNumero non valido. Per favore, seleziona un numero tra 1 e 14.")

if __name__ == "__main__":
    main()
